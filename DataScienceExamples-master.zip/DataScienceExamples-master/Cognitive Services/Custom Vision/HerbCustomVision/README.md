## How to Run

This example uses an `App.json` file that has the prediction and training keys for the Custom Vision service. In order to run this, you would need to add this file with appropriate keys.

It also uses a file `basil_test.jpg` to do predictions on. Feel free to find a photo of basil to use as a test image and see how well your model performs.