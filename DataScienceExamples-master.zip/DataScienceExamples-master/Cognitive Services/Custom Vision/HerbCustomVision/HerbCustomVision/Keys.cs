﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerbPrediction
{
    public class Keys
    {
        public string PredictionKey { get; set; }
        public string TrainingKey { get; set; }
    }
}
