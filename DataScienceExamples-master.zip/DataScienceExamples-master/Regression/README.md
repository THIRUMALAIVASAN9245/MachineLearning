# Regression Notebooks

## Posts on Regression Analysis
- [Simple Regression in Python with scikit-learn](https://www.wintellect.com/creating-a-simple-linear-regression-machine-learning-model-with-scikit-learn/)

Special thanks to [Super DataScience](https://www.superdatascience.com/) for offering their data.