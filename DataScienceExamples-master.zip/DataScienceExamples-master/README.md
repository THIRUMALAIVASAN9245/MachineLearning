# DataScienceExamples
Examples on data science as reference to blog posts.

### Sales Data examples
Two notebooks for blog posts that go over analysis of the data and creating visualizations to find insights about sales. The dataset was provided by [Super Data Science](https://www.superdatascience.com/).
