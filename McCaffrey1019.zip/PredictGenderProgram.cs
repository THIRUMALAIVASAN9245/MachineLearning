﻿using System;
using Microsoft.ML;  // v1.3.1 via NuGet
using Microsoft.ML.Data;
using Microsoft.ML.Trainers;
namespace PredictGender
{
  class PredictGenderProgram
  {
    static void Main(string[] args)
    {
      Console.WriteLine("\nBegin ML.NET predict gender demo \n");
      MLContext mlc = new MLContext(seed: 1);

      // 1. load data and create data pipeline
      Console.WriteLine("Raw data looks like: \n");
      Console.WriteLine("ismale age job   income    satisfac");
      Console.WriteLine("-----------------------------------");
      Console.WriteLine("False  66  mgmt  52100.00  low");
      Console.WriteLine("True   35  tech  86100.00  medium");
      Console.WriteLine(" . . . ");

      Console.WriteLine("\nLoading normalized data into memory \n");
      string trainDataPath =
        "..\\..\\..\\Data\\employees_norm_train.tsv";

      IDataView trainData =
        mlc.Data.LoadFromTextFile<ModelInput>
        (trainDataPath, '\t', hasHeader: true);

      var a = mlc.Transforms.Categorical.OneHotEncoding(new[]
        { new InputOutputColumnPair("job", "job") });
      var b = mlc.Transforms.Categorical.OneHotEncoding(new[]
        { new InputOutputColumnPair("satisfac", "satisfac") });
      var c = mlc.Transforms.Concatenate("Features", new[]
        { "age", "job", "income", "satisfac" });
      var dataPipe = a.Append(b).Append(c);

      // 2. train model
      Console.WriteLine("Creating a L-BFGS logistic regression model");
      var options = new LbfgsLogisticRegressionBinaryTrainer.Options()
      {
        LabelColumnName = "isMale",
        FeatureColumnName = "Features",
        MaximumNumberOfIterations = 100,
        OptimizationTolerance = 1e-8f
      };
      var trainer =
        mlc.BinaryClassification.Trainers.
        LbfgsLogisticRegression(options);
      var trainPipe = dataPipe.Append(trainer);
      Console.WriteLine("Starting training");
      ITransformer model = trainPipe.Fit(trainData);
      Console.WriteLine("Training complete");

      // 3. evaluate model
      IDataView predictions = model.Transform(trainData);
      var metrics = mlc.BinaryClassification.
        EvaluateNonCalibrated(predictions, "isMale", "Score");
      Console.Write("Model accuracy on training data = ");
      Console.WriteLine(metrics.Accuracy.ToString("F4") + "\n");

      // 4. use model
      ModelInput X = new ModelInput();
      X.Age = 0.32f; X.Job = "mgmt"; X.Income = 0.4900f;
      X.Satisfac = "medium";

      var pe = mlc.Model.CreatePredictionEngine<ModelInput,
        ModelOutput>(model);
      var Y = pe.Predict(X);
      Console.Write("Set age = 32, job = mgmt, income = $49K, ");
      Console.WriteLine("satisfac = medium");
      Console.Write("Predicted isMale : ");
      Console.WriteLine(Y.PredictedLabel);

      Console.WriteLine("\nEnd ML.NET demo ");
      Console.ReadLine();
    } // Main
  } // Program

  class ModelInput
  {
    [ColumnName("isMale"), LoadColumn(0)] 
    public bool IsMale { get; set; }

    [ColumnName("age"), LoadColumn(1)]
    public float Age { get; set; }

    [ColumnName("job"), LoadColumn(2)]
    public string Job { get; set; }

    [ColumnName("income"), LoadColumn(3)]
    public float Income { get; set; }

    [ColumnName("satisfac"), LoadColumn(4)]
    public string Satisfac { get; set; }
  }

  class ModelOutput
  {
    [ColumnName("predictedLabel")]
    public bool PredictedLabel { get; set; }

    [ColumnName("score")]
    public float Score { get; set; }
  }

} // ns
