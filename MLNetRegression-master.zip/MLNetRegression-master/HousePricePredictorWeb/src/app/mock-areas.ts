export const AREAS: string[] = [
    '76','11'
];