export class TrainParams {

  constructor(
    public model: string,
    public path: string,
    public testsize: number
  ) {  }

}
