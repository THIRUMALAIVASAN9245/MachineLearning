export class Penguin {

  constructor(
    public island: string,
    public culmenLength: number,
    public culmenDepth: number,
    public flipperLength: number,
    public bodyMass: number,
    public sex: string,
    public species: string,
  ) {  }

}
